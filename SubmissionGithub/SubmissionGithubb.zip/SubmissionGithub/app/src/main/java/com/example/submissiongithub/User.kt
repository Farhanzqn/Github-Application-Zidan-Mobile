package com.example.submissiongithub

data class User (
    val login : String,
    val id: Int,
    val avatar_url: String
    )