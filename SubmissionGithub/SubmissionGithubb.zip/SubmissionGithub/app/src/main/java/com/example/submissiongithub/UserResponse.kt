package com.example.submissiongithub

data class UserResponse(
    val items : ArrayList<User>
)
